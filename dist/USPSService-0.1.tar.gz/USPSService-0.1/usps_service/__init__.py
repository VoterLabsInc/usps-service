from usps_service.address_standardizer import AddressStandardizer

def __init__(user_id):
	self.standardizer = AddressStandardizer(user_id)