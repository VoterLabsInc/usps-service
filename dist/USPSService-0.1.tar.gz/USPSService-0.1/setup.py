from distutils.core import setup

setup(
    name='USPSService',
    version='0.1',
    packages=['usps-service']
)
