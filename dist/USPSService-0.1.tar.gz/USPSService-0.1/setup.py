from distutils.core import setup

setup(
    name='USPSService',
    version='0.1',
    author='Briar Harrison',
    author_email='briar.harrison@voterlabs.com',
    url='voterlabs.com',
    packages=['uspsservice']
)
